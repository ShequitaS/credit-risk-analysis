"""
Credit Risk Scoring & Feature Analysis
=======================================
A complete data science project analyzing loan default risk factors.

Author: [Your Name]
Date: 2026
Tools: Python, Pandas, Scikit-learn, Seaborn, Matplotlib
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score,
    roc_curve, precision_recall_curve, f1_score
)
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. GENERATE SYNTHETIC CREDIT RISK DATASET
# ============================================================
# We create realistic banking data that mirrors what you'd see
# in an actual credit bureau or loan origination system.

np.random.seed(42)
n = 10000

# --- Applicant demographics ---
age = np.random.normal(42, 12, n).clip(21, 75).astype(int)
income = np.random.lognormal(10.8, 0.6, n).clip(18000, 350000).astype(int)

# --- Employment ---
emp_length_years = np.random.exponential(5, n).clip(0, 35).astype(int)

# --- Credit history ---
credit_score = np.random.normal(680, 80, n).clip(300, 850).astype(int)
credit_history_length = (age - 18 - np.random.randint(0, 8, n)).clip(0, 50)

# --- Loan details ---
loan_amount = np.random.lognormal(9.8, 0.7, n).clip(1000, 500000).astype(int)
interest_rate = np.random.normal(10, 4, n).clip(3, 28).round(2)
loan_term_months = np.random.choice([12, 24, 36, 48, 60, 72, 84], n, 
                                     p=[0.05, 0.10, 0.25, 0.20, 0.25, 0.10, 0.05])
loan_purpose = np.random.choice(
    ['debt_consolidation', 'home_improvement', 'major_purchase', 
     'medical', 'auto', 'small_business', 'education'],
    n, p=[0.30, 0.15, 0.12, 0.10, 0.15, 0.10, 0.08]
)

# --- Financial ratios ---
monthly_payment = (loan_amount * (interest_rate/100/12) * 
                   (1 + interest_rate/100/12)**loan_term_months / 
                   ((1 + interest_rate/100/12)**loan_term_months - 1)).round(2)
dti_ratio = ((monthly_payment * 12 + np.random.normal(15000, 8000, n).clip(0, None)) 
             / income * 100).clip(2, 85).round(1)

# --- Payment behavior ---
num_open_accounts = np.random.poisson(5, n).clip(1, 25)
num_delinquencies = np.random.choice(range(0, 8), n, 
                                      p=[0.55, 0.20, 0.10, 0.07, 0.04, 0.02, 0.01, 0.01])
credit_utilization = np.random.beta(2, 5, n).clip(0.01, 0.99).round(3) * 100

# --- Home ownership ---
home_ownership = np.random.choice(['MORTGAGE', 'RENT', 'OWN', 'OTHER'], n,
                                   p=[0.40, 0.35, 0.20, 0.05])

# --- TARGET: Loan Default (realistic probability based on features) ---
# Higher default probability with: high DTI, low credit score, 
# more delinquencies, high utilization, low income
default_logit = (
    0.5
    + 0.04 * dti_ratio
    - 0.008 * credit_score
    + 0.5 * num_delinquencies
    + 0.02 * credit_utilization
    - 0.000008 * income
    + 0.3 * (home_ownership == 'RENT').astype(int)
    + 0.000002 * loan_amount
    + 0.05 * interest_rate
    + np.random.normal(0, 0.5, n)  # noise
)
default_prob = 1 / (1 + np.exp(-default_logit))
loan_default = (np.random.random(n) < default_prob).astype(int)

# Build DataFrame
df = pd.DataFrame({
    'age': age,
    'income': income,
    'employment_length': emp_length_years,
    'credit_score': credit_score,
    'credit_history_length': credit_history_length,
    'loan_amount': loan_amount,
    'interest_rate': interest_rate,
    'loan_term_months': loan_term_months,
    'loan_purpose': loan_purpose,
    'monthly_payment': monthly_payment,
    'dti_ratio': dti_ratio,
    'num_open_accounts': num_open_accounts,
    'num_delinquencies': num_delinquencies,
    'credit_utilization': credit_utilization,
    'home_ownership': home_ownership,
    'loan_default': loan_default
})

# Save the raw dataset
df.to_csv('/home/claude/credit_risk_data.csv', index=False)
print(f"Dataset shape: {df.shape}")
print(f"Default rate: {df['loan_default'].mean():.1%}")
print(f"\n{'='*60}")
print("DATASET OVERVIEW")
print(f"{'='*60}")
print(df.describe().round(2).to_string())


# ============================================================
# 2. EXPLORATORY DATA ANALYSIS
# ============================================================
print(f"\n{'='*60}")
print("EXPLORATORY DATA ANALYSIS")
print(f"{'='*60}")

# Set up visual style
sns.set_style("whitegrid")
plt.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'font.family': 'sans-serif',
    'font.size': 11,
    'axes.titlesize': 14,
    'axes.titleweight': 'bold',
    'figure.titlesize': 16,
    'figure.titleweight': 'bold',
})

BLUE = '#2563EB'
RED = '#DC2626'
COLORS = [BLUE, RED]
palette = {0: BLUE, 1: RED}

# --- Figure 1: Target Distribution ---
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('Loan Default Distribution', fontsize=16, fontweight='bold', y=1.02)

counts = df['loan_default'].value_counts()
axes[0].bar(['No Default', 'Default'], counts.values, color=COLORS, edgecolor='white', width=0.6)
axes[0].set_ylabel('Count')
axes[0].set_title('Default vs Non-Default')
for i, v in enumerate(counts.values):
    axes[0].text(i, v + 100, f'{v:,}\n({v/len(df):.1%})', ha='center', fontweight='bold')

axes[1].pie(counts.values, labels=['No Default', 'Default'], colors=COLORS,
            autopct='%1.1f%%', startangle=90, textprops={'fontweight': 'bold'})
axes[1].set_title('Default Rate Breakdown')

plt.tight_layout()
plt.savefig('/home/claude/fig1_target_distribution.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Figure 1: Target distribution saved")


# --- Figure 2: Key Numeric Features by Default Status ---
fig, axes = plt.subplots(2, 3, figsize=(18, 11))
fig.suptitle('Key Features by Default Status', fontsize=16, fontweight='bold', y=1.02)

features_to_plot = [
    ('credit_score', 'Credit Score'),
    ('dti_ratio', 'Debt-to-Income Ratio (%)'),
    ('income', 'Annual Income ($)'),
    ('credit_utilization', 'Credit Utilization (%)'),
    ('num_delinquencies', 'Number of Delinquencies'),
    ('interest_rate', 'Interest Rate (%)')
]

for ax, (feat, title) in zip(axes.flat, features_to_plot):
    sns.boxplot(data=df, x='loan_default', y=feat, ax=ax, 
                palette={0: BLUE, 1: RED}, hue='loan_default', legend=False, width=0.5)
    ax.set_xticklabels(['No Default', 'Default'])
    ax.set_title(title)
    ax.set_xlabel('')

plt.tight_layout()
plt.savefig('/home/claude/fig2_features_by_default.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Figure 2: Feature distributions by default status saved")


# --- Figure 3: Correlation Heatmap ---
fig, ax = plt.subplots(figsize=(14, 10))
numeric_cols = df.select_dtypes(include=[np.number]).columns
corr = df[numeric_cols].corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, annot=True, fmt='.2f', cmap='RdBu_r', center=0,
            ax=ax, square=True, linewidths=0.5, vmin=-1, vmax=1,
            cbar_kws={'shrink': 0.8})
ax.set_title('Correlation Matrix — Numeric Features', fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('/home/claude/fig3_correlation_heatmap.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Figure 3: Correlation heatmap saved")


# --- Figure 4: Default Rate by Categorical Features ---
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle('Default Rate by Category', fontsize=16, fontweight='bold', y=1.02)

# By loan purpose
purpose_default = df.groupby('loan_purpose')['loan_default'].mean().sort_values(ascending=False)
bars = axes[0].barh(purpose_default.index, purpose_default.values, color=BLUE, edgecolor='white')
axes[0].set_xlabel('Default Rate')
axes[0].set_title('Default Rate by Loan Purpose')
axes[0].xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x:.0%}'))
for bar, val in zip(bars, purpose_default.values):
    axes[0].text(val + 0.003, bar.get_y() + bar.get_height()/2, f'{val:.1%}', 
                 va='center', fontweight='bold', fontsize=10)

# By home ownership
home_default = df.groupby('home_ownership')['loan_default'].mean().sort_values(ascending=False)
bars = axes[1].barh(home_default.index, home_default.values, color=BLUE, edgecolor='white')
axes[1].set_xlabel('Default Rate')
axes[1].set_title('Default Rate by Home Ownership')
axes[1].xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x:.0%}'))
for bar, val in zip(bars, home_default.values):
    axes[1].text(val + 0.003, bar.get_y() + bar.get_height()/2, f'{val:.1%}', 
                 va='center', fontweight='bold', fontsize=10)

plt.tight_layout()
plt.savefig('/home/claude/fig4_categorical_defaults.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Figure 4: Categorical default rates saved")


# --- Figure 5: Credit Score vs DTI colored by default ---
fig, ax = plt.subplots(figsize=(12, 8))
scatter = ax.scatter(
    df['credit_score'], df['dti_ratio'],
    c=df['loan_default'], cmap='RdBu_r', alpha=0.3, s=10, edgecolors='none'
)
ax.set_xlabel('Credit Score', fontsize=13)
ax.set_ylabel('Debt-to-Income Ratio (%)', fontsize=13)
ax.set_title('Credit Score vs DTI Ratio — Colored by Default Status', 
             fontsize=16, fontweight='bold')
legend = ax.legend(*scatter.legend_elements(), title='Default', labels=['No', 'Yes'],
                    loc='upper right', fontsize=11)
ax.add_artist(legend)
plt.tight_layout()
plt.savefig('/home/claude/fig5_scatter_score_dti.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Figure 5: Credit score vs DTI scatter saved")


# ============================================================
# 3. DATA PREPROCESSING
# ============================================================
print(f"\n{'='*60}")
print("DATA PREPROCESSING")
print(f"{'='*60}")

# Encode categoricals
df_model = df.copy()
le_purpose = LabelEncoder()
le_home = LabelEncoder()
df_model['loan_purpose_encoded'] = le_purpose.fit_transform(df_model['loan_purpose'])
df_model['home_ownership_encoded'] = le_home.fit_transform(df_model['home_ownership'])

# Feature set (exclude target + raw categoricals + monthly_payment which leaks info)
feature_cols = [
    'age', 'income', 'employment_length', 'credit_score', 
    'credit_history_length', 'loan_amount', 'interest_rate',
    'loan_term_months', 'dti_ratio', 'num_open_accounts',
    'num_delinquencies', 'credit_utilization',
    'loan_purpose_encoded', 'home_ownership_encoded'
]

X = df_model[feature_cols]
y = df_model['loan_default']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print(f"Training set: {X_train.shape[0]:,} samples")
print(f"Test set:     {X_test.shape[0]:,} samples")
print(f"Default rate (train): {y_train.mean():.1%}")
print(f"Default rate (test):  {y_test.mean():.1%}")


# ============================================================
# 4. MODEL TRAINING & EVALUATION
# ============================================================
print(f"\n{'='*60}")
print("MODEL TRAINING & EVALUATION")
print(f"{'='*60}")

# --- Logistic Regression ---
lr = LogisticRegression(max_iter=1000, random_state=42)
lr.fit(X_train_scaled, y_train)
lr_pred = lr.predict(X_test_scaled)
lr_prob = lr.predict_proba(X_test_scaled)[:, 1]

lr_cv = cross_val_score(lr, X_train_scaled, y_train, cv=5, scoring='roc_auc')

print("\n--- Logistic Regression ---")
print(f"ROC-AUC (test):  {roc_auc_score(y_test, lr_prob):.4f}")
print(f"ROC-AUC (5-fold CV): {lr_cv.mean():.4f} ± {lr_cv.std():.4f}")
print(f"F1 Score: {f1_score(y_test, lr_pred):.4f}")
print(classification_report(y_test, lr_pred, target_names=['No Default', 'Default']))

# --- Random Forest ---
rf = RandomForestClassifier(n_estimators=200, max_depth=12, min_samples_leaf=10,
                            random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_test)
rf_prob = rf.predict_proba(X_test)[:, 1]

rf_cv = cross_val_score(rf, X_train, y_train, cv=5, scoring='roc_auc')

print("\n--- Random Forest ---")
print(f"ROC-AUC (test):  {roc_auc_score(y_test, rf_prob):.4f}")
print(f"ROC-AUC (5-fold CV): {rf_cv.mean():.4f} ± {rf_cv.std():.4f}")
print(f"F1 Score: {f1_score(y_test, rf_pred):.4f}")
print(classification_report(y_test, rf_pred, target_names=['No Default', 'Default']))


# --- Figure 6: ROC Curves ---
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle('Model Performance', fontsize=16, fontweight='bold', y=1.02)

# ROC curves
for name, probs, color in [('Logistic Regression', lr_prob, BLUE), 
                             ('Random Forest', rf_prob, RED)]:
    fpr, tpr, _ = roc_curve(y_test, probs)
    auc = roc_auc_score(y_test, probs)
    axes[0].plot(fpr, tpr, color=color, lw=2, label=f'{name} (AUC = {auc:.3f})')

axes[0].plot([0, 1], [0, 1], 'k--', lw=1, alpha=0.5)
axes[0].set_xlabel('False Positive Rate')
axes[0].set_ylabel('True Positive Rate')
axes[0].set_title('ROC Curves')
axes[0].legend(fontsize=11)

# Confusion matrix for best model (RF)
cm = confusion_matrix(y_test, rf_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[1],
            xticklabels=['No Default', 'Default'],
            yticklabels=['No Default', 'Default'],
            cbar_kws={'shrink': 0.8})
axes[1].set_xlabel('Predicted')
axes[1].set_ylabel('Actual')
axes[1].set_title('Confusion Matrix — Random Forest')

plt.tight_layout()
plt.savefig('/home/claude/fig6_model_performance.png', dpi=150, bbox_inches='tight')
plt.close()
print("\n✓ Figure 6: ROC curves and confusion matrix saved")


# --- Figure 7: Feature Importance ---
fig, axes = plt.subplots(1, 2, figsize=(18, 8))
fig.suptitle('Feature Importance Analysis', fontsize=16, fontweight='bold', y=1.02)

# Random Forest feature importance
feat_imp = pd.Series(rf.feature_importances_, index=feature_cols).sort_values()
feat_imp.plot(kind='barh', ax=axes[0], color=BLUE, edgecolor='white')
axes[0].set_title('Random Forest — Feature Importance')
axes[0].set_xlabel('Importance Score')

# Logistic Regression coefficients (absolute value)
lr_coefs = pd.Series(np.abs(lr.coef_[0]), index=feature_cols).sort_values()
lr_coefs.plot(kind='barh', ax=axes[1], color=RED, edgecolor='white')
axes[1].set_title('Logistic Regression — Absolute Coefficients')
axes[1].set_xlabel('|Coefficient|')

plt.tight_layout()
plt.savefig('/home/claude/fig7_feature_importance.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Figure 7: Feature importance saved")


# ============================================================
# 5. KEY FINDINGS SUMMARY
# ============================================================
print(f"\n{'='*60}")
print("KEY FINDINGS")
print(f"{'='*60}")

# Top features from RF
top_features = pd.Series(rf.feature_importances_, index=feature_cols).sort_values(ascending=False)

print("\nTop 5 Default Predictors (Random Forest):")
for i, (feat, score) in enumerate(top_features.head(5).items(), 1):
    print(f"  {i}. {feat:30s} — importance: {score:.4f}")

print(f"\nModel Comparison:")
print(f"  Logistic Regression  AUC: {roc_auc_score(y_test, lr_prob):.4f}")
print(f"  Random Forest        AUC: {roc_auc_score(y_test, rf_prob):.4f}")

best_auc = max(roc_auc_score(y_test, lr_prob), roc_auc_score(y_test, rf_prob))
print(f"\n  Best model AUC: {best_auc:.4f}")

# Default rates by key segments
print(f"\nDefault Rate by Key Segments:")
print(f"  Low credit score (<600):    {df[df['credit_score'] < 600]['loan_default'].mean():.1%}")
print(f"  High credit score (>750):   {df[df['credit_score'] > 750]['loan_default'].mean():.1%}")
print(f"  High DTI (>50%):            {df[df['dti_ratio'] > 50]['loan_default'].mean():.1%}")
print(f"  Low DTI (<20%):             {df[df['dti_ratio'] < 20]['loan_default'].mean():.1%}")
print(f"  Any delinquencies:          {df[df['num_delinquencies'] > 0]['loan_default'].mean():.1%}")
print(f"  No delinquencies:           {df[df['num_delinquencies'] == 0]['loan_default'].mean():.1%}")

print(f"\n{'='*60}")
print("All outputs saved. Project complete!")
print(f"{'='*60}")
